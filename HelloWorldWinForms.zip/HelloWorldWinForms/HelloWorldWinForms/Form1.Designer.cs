﻿
namespace HelloWorldWinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_hello = new System.Windows.Forms.Button();
            this.lbl_helloMessage = new System.Windows.Forms.Label();
            this.btn_changeColor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_hello
            // 
            this.btn_hello.Location = new System.Drawing.Point(267, 162);
            this.btn_hello.Name = "btn_hello";
            this.btn_hello.Size = new System.Drawing.Size(175, 79);
            this.btn_hello.TabIndex = 0;
            this.btn_hello.Text = "Hello Click Me";
            this.btn_hello.UseVisualStyleBackColor = true;
            this.btn_hello.Click += new System.EventHandler(this.btn_hello_Click);
            // 
            // lbl_helloMessage
            // 
            this.lbl_helloMessage.AutoSize = true;
            this.lbl_helloMessage.Location = new System.Drawing.Point(348, 264);
            this.lbl_helloMessage.Name = "lbl_helloMessage";
            this.lbl_helloMessage.Size = new System.Drawing.Size(0, 13);
            this.lbl_helloMessage.TabIndex = 1;
            this.lbl_helloMessage.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_changeColor
            // 
            this.btn_changeColor.Location = new System.Drawing.Point(497, 162);
            this.btn_changeColor.Name = "btn_changeColor";
            this.btn_changeColor.Size = new System.Drawing.Size(140, 59);
            this.btn_changeColor.TabIndex = 2;
            this.btn_changeColor.Text = "change color";
            this.btn_changeColor.UseVisualStyleBackColor = true;
            this.btn_changeColor.Click += new System.EventHandler(this.btn_changeColor_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_changeColor);
            this.Controls.Add(this.lbl_helloMessage);
            this.Controls.Add(this.btn_hello);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_hello;
        private System.Windows.Forms.Label lbl_helloMessage;
        private System.Windows.Forms.Button btn_changeColor;
    }
}

