﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace magicDateApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime d = dateTimePicker.Value;

          
            int day = d.Day;
            int month = d.Month;
            int year = d.Year;
            year = year % 100;
            int magicNum = day + month;
            if (magicNum == year)
            {
                magicLabel.Text = "That's a magic number!" ;
            }
            else
            {
                magicLabel.Text = "That's an ordinary number";
            }
            dayLabel.Text = "Day: " + day;
            monthLabel.Text = "Month: " + month;
            yearLabel.Text = "Year: " + year;
            sumLabel.Text = "Sum: " + magicNum;
;

        }
    }
}
