﻿
namespace tempConvert
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.farLabel = new System.Windows.Forms.Label();
            this.celLabel = new System.Windows.Forms.Label();
            this.kelLabel = new System.Windows.Forms.Label();
            this.far_text = new System.Windows.Forms.TextBox();
            this.cel_text = new System.Windows.Forms.TextBox();
            this.kel_text = new System.Windows.Forms.TextBox();
            this.far_btn = new System.Windows.Forms.Button();
            this.cel_btn = new System.Windows.Forms.Button();
            this.kel_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // farLabel
            // 
            this.farLabel.AutoSize = true;
            this.farLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.farLabel.Location = new System.Drawing.Point(12, 28);
            this.farLabel.Name = "farLabel";
            this.farLabel.Size = new System.Drawing.Size(112, 24);
            this.farLabel.TabIndex = 0;
            this.farLabel.Text = "Farenheight";
            // 
            // celLabel
            // 
            this.celLabel.AutoSize = true;
            this.celLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.celLabel.Location = new System.Drawing.Point(53, 163);
            this.celLabel.Name = "celLabel";
            this.celLabel.Size = new System.Drawing.Size(71, 24);
            this.celLabel.TabIndex = 1;
            this.celLabel.Text = "Celsius";
            // 
            // kelLabel
            // 
            this.kelLabel.AutoSize = true;
            this.kelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kelLabel.Location = new System.Drawing.Point(63, 298);
            this.kelLabel.Name = "kelLabel";
            this.kelLabel.Size = new System.Drawing.Size(61, 24);
            this.kelLabel.TabIndex = 2;
            this.kelLabel.Text = "Kelvin";
            // 
            // far_text
            // 
            this.far_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.far_text.Location = new System.Drawing.Point(184, 28);
            this.far_text.Name = "far_text";
            this.far_text.Size = new System.Drawing.Size(148, 29);
            this.far_text.TabIndex = 3;
            // 
            // cel_text
            // 
            this.cel_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cel_text.Location = new System.Drawing.Point(184, 163);
            this.cel_text.Name = "cel_text";
            this.cel_text.Size = new System.Drawing.Size(148, 29);
            this.cel_text.TabIndex = 4;
            // 
            // kel_text
            // 
            this.kel_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kel_text.Location = new System.Drawing.Point(184, 298);
            this.kel_text.Name = "kel_text";
            this.kel_text.Size = new System.Drawing.Size(148, 29);
            this.kel_text.TabIndex = 5;
            // 
            // far_btn
            // 
            this.far_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.far_btn.Location = new System.Drawing.Point(394, 28);
            this.far_btn.Name = "far_btn";
            this.far_btn.Size = new System.Drawing.Size(75, 29);
            this.far_btn.TabIndex = 6;
            this.far_btn.Text = "Go";
            this.far_btn.UseVisualStyleBackColor = true;
            this.far_btn.Click += new System.EventHandler(this.far_btn_Click);
            // 
            // cel_btn
            // 
            this.cel_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cel_btn.Location = new System.Drawing.Point(394, 162);
            this.cel_btn.Name = "cel_btn";
            this.cel_btn.Size = new System.Drawing.Size(75, 30);
            this.cel_btn.TabIndex = 7;
            this.cel_btn.Text = "Go";
            this.cel_btn.UseVisualStyleBackColor = true;
            this.cel_btn.Click += new System.EventHandler(this.cel_btn_Click);
            // 
            // kel_btn
            // 
            this.kel_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kel_btn.Location = new System.Drawing.Point(394, 297);
            this.kel_btn.Name = "kel_btn";
            this.kel_btn.Size = new System.Drawing.Size(75, 29);
            this.kel_btn.TabIndex = 8;
            this.kel_btn.Text = "Go";
            this.kel_btn.UseVisualStyleBackColor = true;
            this.kel_btn.Click += new System.EventHandler(this.kel_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 344);
            this.Controls.Add(this.kel_btn);
            this.Controls.Add(this.cel_btn);
            this.Controls.Add(this.far_btn);
            this.Controls.Add(this.kel_text);
            this.Controls.Add(this.cel_text);
            this.Controls.Add(this.far_text);
            this.Controls.Add(this.kelLabel);
            this.Controls.Add(this.celLabel);
            this.Controls.Add(this.farLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label farLabel;
        private System.Windows.Forms.Label celLabel;
        private System.Windows.Forms.Label kelLabel;
        private System.Windows.Forms.TextBox far_text;
        private System.Windows.Forms.TextBox cel_text;
        private System.Windows.Forms.TextBox kel_text;
        private System.Windows.Forms.Button far_btn;
        private System.Windows.Forms.Button cel_btn;
        private System.Windows.Forms.Button kel_btn;
    }
}

