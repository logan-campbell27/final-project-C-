﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tempConvert
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void far_btn_Click(object sender, EventArgs e)
        {
             float f = 0;
            try
            {
                f = float.Parse(far_text.Text);

            }

            catch
            {
                MessageBox.Show("Try Only Numbers");
            }


            float c = 5f / 9 * (f - 32);
            cel_text.Text = c.ToString();
            float k = c - 273;
            kel_text.Text = k.ToString();
        }
        private void cel_btn_Click(object sender, EventArgs e)
        {
            float c = 0;
            try
            {
                 c = float.Parse(cel_text.Text);

            }

            catch
            {
                MessageBox.Show("Try Only Numbers");
            }
            

            float f = (9f / 5 * c) + 32;

            far_text.Text = f.ToString();
            
            float k = c - 273;

            kel_text.Text = k.ToString();
        }

       

        private void kel_btn_Click(object sender, EventArgs e)
        {
            float k = 0;
            try
            {
                 k = float.Parse(kel_text.Text);

            }

            catch
            {
                MessageBox.Show("Try Only Numbers");
            }
            

            float c = k + 273;

            cel_text.Text = c.ToString();

            float f = (9f / 5 * c) + 32;

            far_text.Text = f.ToString();
        }
    }
}
